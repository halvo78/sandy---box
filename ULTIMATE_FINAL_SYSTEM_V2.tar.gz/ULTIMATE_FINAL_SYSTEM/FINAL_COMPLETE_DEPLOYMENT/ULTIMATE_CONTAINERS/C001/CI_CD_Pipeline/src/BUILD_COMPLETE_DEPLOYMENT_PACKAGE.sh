#!/bin/bash

# BUILD COMPLETE DEPLOYMENT PACKAGE
# Creates a single, comprehensive package for deployment to local Ubuntu

set -e

echo "======================================================================"
echo "🚀 BUILDING COMPLETE DEPLOYMENT PACKAGE"
echo "======================================================================"

# Create deployment directory
DEPLOY_DIR="/home/ubuntu/ULTIMATE_DEPLOYMENT_PACKAGE"
rm -rf $DEPLOY_DIR
mkdir -p $DEPLOY_DIR

# Copy the ultimate upload receiver
cp upload_receiver_ultimate.py $DEPLOY_DIR/

# Create the deployment script for local Ubuntu
cat > $DEPLOY_DIR/DEPLOY_ON_LOCAL_UBUNTU.sh << 'EOF'
#!/bin/bash

# DEPLOY ON LOCAL UBUNTU - Complete System Deployment
# Run this script on halvolyra@HALVO-AI

set -e

echo "======================================================================"
echo "🚀 DEPLOYING COMPLETE TRADING SYSTEM ON LOCAL UBUNTU"
echo "======================================================================"

# Configuration
SYSTEM_DIR="$HOME/ultimate_lyra_systems"
cd $SYSTEM_DIR

# Check if ISO_COMPLIANT_SYSTEM exists
if [ ! -d "ISO_COMPLIANT_SYSTEM" ]; then
    echo "❌ ERROR: ISO_COMPLIANT_SYSTEM directory not found!"
    echo "📁 Current directory: $(pwd)"
    echo "📂 Contents:"
    ls -la
    exit 1
fi

cd ISO_COMPLIANT_SYSTEM

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv trading_env
source trading_env/bin/activate

# Install dependencies
echo "📥 Installing dependencies..."
pip install --upgrade pip
pip install ccxt pandas numpy fastapi uvicorn streamlit plotly aiofiles

# Start all trading system components
echo "🚀 Starting trading system components..."

# Paper Trading
nohup python3 src/trading_systems/paper_trading_mode.py > logs/paper_trading.log 2>&1 &
echo "✅ Paper Trading started (PID: $!)"

# Live Dashboard API
nohup python3 src/enterprise_systems/live_dashboard_api.py > logs/dashboard_api.log 2>&1 &
echo "✅ Live Dashboard API started (PID: $!)"

# WebSocket Feed
nohup python3 src/trading_systems/realtime_websocket_feed.py > logs/websocket.log 2>&1 &
echo "✅ WebSocket Feed started (PID: $!)"

# Backtesting Engine
nohup python3 src/trading_systems/backtesting_engine.py > logs/backtesting.log 2>&1 &
echo "✅ Backtesting Engine started (PID: $!)"

# Automated Rebalancer
nohup python3 src/trading_systems/automated_rebalancer.py > logs/rebalancer.log 2>&1 &
echo "✅ Automated Rebalancer started (PID: $!)"

# Stop Loss Manager
nohup python3 src/trading_systems/automated_stop_loss_manager.py > logs/stop_loss.log 2>&1 &
echo "✅ Stop Loss Manager started (PID: $!)"

sleep 3

# Verify all processes are running
echo ""
echo "======================================================================"
echo "📊 SYSTEM STATUS"
echo "======================================================================"
ps aux | grep python3 | grep -v grep

echo ""
echo "======================================================================"
echo "✅ DEPLOYMENT COMPLETE!"
echo "======================================================================"
echo "📁 System Directory: $SYSTEM_DIR/ISO_COMPLIANT_SYSTEM"
echo "📝 Logs Directory: $SYSTEM_DIR/ISO_COMPLIANT_SYSTEM/logs"
echo ""
echo "To view logs:"
echo "  tail -f logs/paper_trading.log"
echo "  tail -f logs/dashboard_api.log"
echo ""
echo "To stop all systems:"
echo "  pkill -f 'python3 src/'"
EOF

chmod +x $DEPLOY_DIR/DEPLOY_ON_LOCAL_UBUNTU.sh

# Create README
cat > $DEPLOY_DIR/README.md << 'EOF'
# ULTIMATE DEPLOYMENT PACKAGE

## Complete System Integration: Ngrok + Manus + Trading System

### Package Contents

1. **upload_receiver_ultimate.py** - Ultimate Upload Receiver & Control Server
2. **DEPLOY_ON_LOCAL_UBUNTU.sh** - Deployment script for local Ubuntu system
3. **README.md** - This file

### Deployment Instructions

#### On Manus Sandbox:

```bash
# 1. Start the Ultimate Upload Receiver
python3 upload_receiver_ultimate.py
```

#### On Local Ubuntu (halvolyra@HALVO-AI):

```bash
# 1. Download this package via Ngrok
curl -O https://6572610f15aa.ngrok.app/download/ULTIMATE_DEPLOYMENT_PACKAGE.tar.gz

# 2. Extract
tar -xzf ULTIMATE_DEPLOYMENT_PACKAGE.tar.gz
cd ULTIMATE_DEPLOYMENT_PACKAGE

# 3. Run deployment script
./DEPLOY_ON_LOCAL_UBUNTU.sh
```

### System Components

The deployment will start:
- Paper Trading System
- Live Dashboard API
- Real-time WebSocket Feed
- Backtesting Engine
- Automated Rebalancer
- Stop Loss Manager

### Monitoring

Access the monitoring dashboard at:
https://6572610f15aa.ngrok.app

### Troubleshooting

If deployment fails:
1. Check that ISO_COMPLIANT_SYSTEM exists in ~/ultimate_lyra_systems
2. Ensure Python 3 is installed
3. Check logs in ISO_COMPLIANT_SYSTEM/logs/

EOF

# Create the package
cd /home/ubuntu
tar -czf ULTIMATE_DEPLOYMENT_PACKAGE.tar.gz -C ULTIMATE_DEPLOYMENT_PACKAGE .

echo ""
echo "======================================================================"
echo "✅ PACKAGE BUILT SUCCESSFULLY!"
echo "======================================================================"
echo "📦 Package: /home/ubuntu/ULTIMATE_DEPLOYMENT_PACKAGE.tar.gz"
echo "📊 Size: $(du -h ULTIMATE_DEPLOYMENT_PACKAGE.tar.gz | cut -f1)"
echo ""
echo "To upload to your local Ubuntu:"
echo "  curl -F 'file=@ULTIMATE_DEPLOYMENT_PACKAGE.tar.gz' https://6572610f15aa.ngrok.app/upload"
echo ""
echo "======================================================================"

