#!/usr/bin/env python3
"""
ASSEMBLE WORLD'S BEST AI TEAM
Consult ALL OpenRouter AIs to create the ultimate team structure
"""

import asyncio
import aiohttp
import json
import os
from datetime import datetime

# Use the OpenRouter API key from environment
OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY')

# ALL available top AI models in OpenRouter
ALL_AI_MODELS = [
    # Grok builders
    "x-ai/grok-beta",
    "x-ai/grok-2-vision-1212",
    
    # Claude models
    "anthropic/claude-3.5-sonnet",
    "anthropic/claude-3-opus",
    "anthropic/claude-3-haiku",
    
    # GPT models
    "openai/gpt-4-turbo",
    "openai/gpt-4",
    "openai/gpt-3.5-turbo",
    
    # Gemini models
    "google/gemini-2.0-flash-exp:free",
    "google/gemini-pro",
    
    # Llama models
    "meta-llama/llama-3.3-70b-instruct",
    "meta-llama/llama-3.1-405b-instruct",
    
    # Qwen models
    "qwen/qwen-2.5-72b-instruct",
    "qwen/qwq-32b-preview",
    
    # DeepSeek models
    "deepseek/deepseek-chat",
    "deepseek/deepseek-coder",
    
    # Other top models
    "mistralai/mistral-large",
    "cohere/command-r-plus",
    "perplexity/llama-3.1-sonar-large-128k-online",
]

TEAM_ASSEMBLY_PROMPT = """You are assembling the WORLD'S BEST AI TEAM to build a production-grade cryptocurrency trading system.

Based on the forensic analysis, we need to build 10 missing components:
1. Automated Testing & CI/CD Pipeline
2. Real-time Data Pipeline
3. Advanced Risk Management Module
4. Security Framework
5. Performance Monitoring Dashboard
6. Core Trading System Documentation
7. Version Control for Core System
8. Disaster Recovery Plan
9. Compliance Module
10. Enhanced AI Consensus Module

**YOUR TASK:**
Design the ultimate team structure with specific roles, skills, and responsibilities. For each role:
- Specify the exact title (e.g., "Senior DevOps Engineer - CI/CD Specialist")
- List required PhD-level skills
- Define specific responsibilities
- Suggest which AI models are best suited for this role

**REQUIREMENTS:**
- Team must be world-class, PhD-level specialists
- Each role must have clear, non-overlapping responsibilities
- Team must cover all 10 missing components
- Include forensic analysts, security experts, and quality assurance specialists
- Design for parallel execution of all 10 components

Provide your response in JSON format:
{
  "team_structure": [
    {
      "role_id": 1,
      "title": "...",
      "skills": ["...", "..."],
      "responsibilities": ["...", "..."],
      "components": [1, 2],
      "recommended_ai_models": ["...", "..."]
    }
  ],
  "execution_strategy": "...",
  "success_criteria": ["...", "..."]
}
"""

async def consult_ai(session, model, prompt):
    """Consult a single AI model"""
    try:
        async with session.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}]
            },
            timeout=aiohttp.ClientTimeout(total=120)
        ) as response:
            if response.status == 200:
                data = await response.json()
                return {
                    "model": model,
                    "success": True,
                    "response": data['choices'][0]['message']['content']
                }
            else:
                return {
                    "model": model,
                    "success": False,
                    "error": f"HTTP {response.status}"
                }
    except Exception as e:
        return {
            "model": model,
            "success": False,
            "error": str(e)
        }

async def main():
    print("🚀 ASSEMBLING WORLD'S BEST AI TEAM")
    print("=" * 70)
    print(f"Consulting {len(ALL_AI_MODELS)} top AI models...")
    print()
    
    async with aiohttp.ClientSession() as session:
        tasks = [consult_ai(session, model, TEAM_ASSEMBLY_PROMPT) for model in ALL_AI_MODELS]
        results = await asyncio.gather(*tasks)
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = f"/home/ubuntu/AI_TEAM_ASSEMBLY_RESULTS_{timestamp}.json"
    
    with open(results_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    # Create summary
    successful = [r for r in results if r['success']]
    failed = [r for r in results if not r['success']]
    
    summary = f"""# AI TEAM ASSEMBLY SUMMARY

**Timestamp:** {datetime.now().isoformat()}

## Results

- **Total AIs Consulted:** {len(ALL_AI_MODELS)}
- **Successful Responses:** {len(successful)}
- **Failed Responses:** {len(failed)}

## Successful AI Models

{chr(10).join(f"- {r['model']}" for r in successful)}

## Failed AI Models

{chr(10).join(f"- {r['model']}: {r['error']}" for r in failed)}

## Next Steps

1. Analyze all successful responses
2. Extract best team structure from AI consensus
3. Create ultimate command structure
4. Begin parallel execution of all 10 components

**Results saved to:** {results_file}
"""
    
    summary_file = f"/home/ubuntu/AI_TEAM_ASSEMBLY_SUMMARY_{timestamp}.md"
    with open(summary_file, 'w') as f:
        f.write(summary)
    
    print(summary)
    print()
    print(f"✅ Results saved to: {results_file}")
    print(f"✅ Summary saved to: {summary_file}")

if __name__ == "__main__":
    asyncio.run(main())

