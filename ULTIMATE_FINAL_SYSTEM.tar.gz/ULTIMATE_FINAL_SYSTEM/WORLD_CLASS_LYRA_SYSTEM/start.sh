#!/bin/bash
# Start World-Class Lyra System

set -e

echo "🚀 Starting World-Class Lyra System"
echo "===================================="

# Start HFT Core
echo "Starting HFT Core..."
cd hft-core
python3 main.py &
HFT_PID=$!
cd ..

# Start Dashboard
echo "Starting Dashboard..."
cd dashboard-ui
pnpm dev &
DASHBOARD_PID=$!
cd ..

echo ""
echo "✅ System Started!"
echo ""
echo "Services:"
echo "  - HFT Core: PID $HFT_PID"
echo "  - Dashboard: PID $DASHBOARD_PID"
echo "  - Dashboard URL: http://localhost:3000"
echo ""
echo "To stop: ./stop.sh"
