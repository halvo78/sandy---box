#!/usr/bin/env python3
"""
OPTIMIZED Order Execution System
Performance improvements implemented
"""

import asyncio
import aiohttp
import logging
from typing import Dict, List
from functools import lru_cache
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OptimizedOrderExecutionSystem:
    """High-performance order execution with async operations"""
    
    def __init__(self):
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        # FIXED: Async session with connection pooling
        connector = aiohttp.TCPConnector(
            limit=100,  # Connection pool size
            limit_per_host=30,
            ttl_dns_cache=300
        )
        self.session = aiohttp.ClientSession(connector=connector)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    @lru_cache(maxsize=10000)
    def calculate_order_params(self, symbol: str, quantity: float, price: float) -> Dict:
        """
        Calculate order parameters with caching
        
        FIXED: Added caching for repeated calculations
        """
        return {
            "symbol": symbol,
            "quantity": quantity,
            "price": price,
            "total": quantity * price
        }
    
    async def execute_order_async(self, exchange_url: str, order_data: Dict) -> Dict:
        """
        Execute order asynchronously
        
        FIXED:
        - Async I/O for non-blocking execution
        - Proper timeout handling
        - Connection pooling
        """
        try:
            async with self.session.post(
                exchange_url,
                json=order_data,
                timeout=aiohttp.ClientTimeout(total=5)
            ) as response:
                response.raise_for_status()
                return await response.json()
                
        except asyncio.TimeoutError:
            logger.error(f"Timeout executing order on {exchange_url}")
            return {"error": "timeout"}
        except aiohttp.ClientError as e:
            logger.error(f"Client error: {e}")
            return {"error": str(e)}
    
    async def execute_multiple_orders(self, orders: List[Dict]) -> List[Dict]:
        """
        Execute multiple orders in parallel
        
        FIXED: Parallel execution for better performance
        """
        tasks = [
            self.execute_order_async(order["exchange_url"], order["data"])
            for order in orders
        ]
        return await asyncio.gather(*tasks, return_exceptions=True)

async def main():
    """Example usage"""
    async with OptimizedOrderExecutionSystem() as system:
        orders = [
            {"exchange_url": "https://api.exchange1.com/order", "data": {"symbol": "BTC", "qty": 1}},
            {"exchange_url": "https://api.exchange2.com/order", "data": {"symbol": "ETH", "qty": 10}}
        ]
        results = await system.execute_multiple_orders(orders)
        logger.info(f"Results: {results}")

if __name__ == "__main__":
    asyncio.run(main())
