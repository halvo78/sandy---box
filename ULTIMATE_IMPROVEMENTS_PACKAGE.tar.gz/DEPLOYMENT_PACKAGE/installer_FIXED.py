#!/usr/bin/env python3
"""
FIXED Installer - Security Vulnerabilities Removed
"""

import os
import subprocess
import logging
from pathlib import Path
from typing import List, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SecureInstaller:
    """Production-ready installer with security fixes"""
    
    def __init__(self):
        # FIXED: Use environment variable or config for paths
        self.install_dir = Path(os.environ.get(
            "INSTALL_DIR",
            str(Path.home() / "lyra_systems")
        ))
        self.install_dir.mkdir(parents=True, exist_ok=True)
    
    def run_command(self, command: List[str]) -> bool:
        """
        Run command securely
        
        FIXED:
        - Removed shell=True (RCE vulnerability)
        - Command as list instead of string
        - Proper error handling
        - No sensitive info in logs
        """
        try:
            # FIXED: shell=False, command as list
            result = subprocess.run(
                command,
                shell=False,  # CRITICAL FIX: No shell injection
                check=True,
                capture_output=True,
                text=True,
                timeout=300
            )
            
            logger.info(f"Command succeeded: {' '.join(command)}")
            return True
            
        except subprocess.TimeoutExpired:
            logger.error(f"Command timeout: {' '.join(command)}")
            return False
        except subprocess.CalledProcessError as e:
            logger.error(f"Command failed: {' '.join(command)}")
            logger.error(f"Return code: {e.returncode}")
            # FIXED: Don't log stderr (may contain sensitive info)
            return False
        except Exception as e:
            logger.error(f"Unexpected error: {type(e).__name__}")
            return False
    
    def install_package(self, package_name: str) -> bool:
        """Install Python package securely"""
        # FIXED: Validate package name
        if not package_name.replace('-', '').replace('_', '').isalnum():
            logger.error(f"Invalid package name: {package_name}")
            return False
        
        # FIXED: Command as list, no shell=True
        return self.run_command(["pip3", "install", package_name])

if __name__ == "__main__":
    installer = SecureInstaller()
    installer.install_package("requests")
