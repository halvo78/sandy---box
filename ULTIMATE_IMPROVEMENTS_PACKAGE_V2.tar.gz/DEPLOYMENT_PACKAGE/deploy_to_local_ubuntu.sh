#!/bin/bash
#
# AUTOMATED DEPLOYMENT SCRIPT
# Deploy all components to ~/ultimate_lyra_systems/
#

set -e

echo "🚀 DEPLOYING ALL COMPONENTS TO LOCAL UBUNTU"
echo "="*80
echo ""

# Base directory
BASE_DIR="$HOME/ultimate_lyra_systems"

# Create directory structure
echo "📁 Creating directory structure..."
mkdir -p "$BASE_DIR/dashboards"
mkdir -p "$BASE_DIR/apis"
mkdir -p "$BASE_DIR/trading/hft"
mkdir -p "$BASE_DIR/trading/strategies"
mkdir -p "$BASE_DIR/trading/analysis"
mkdir -p "$BASE_DIR/ai"
mkdir -p "$BASE_DIR/advanced/arbitrage"
mkdir -p "$BASE_DIR/advanced/charts"
mkdir -p "$BASE_DIR/monetization"
mkdir -p "$BASE_DIR/logs"
mkdir -p "$BASE_DIR/backups"

echo "✅ Directory structure created"
echo ""

# Copy components
echo "📦 Copying components..."

if [ -d "dashboards" ]; then
    cp -r dashboards/* "$BASE_DIR/dashboards/"
    echo "✅ Dashboard UI deployed"
fi

if [ -d "apis" ]; then
    cp -r apis/* "$BASE_DIR/apis/"
    echo "✅ API integrations deployed"
fi

if [ -d "trading" ]; then
    cp -r trading/* "$BASE_DIR/trading/"
    echo "✅ Trading engine deployed"
fi

if [ -d "ai" ]; then
    cp -r ai/* "$BASE_DIR/ai/"
    echo "✅ AI consensus system deployed"
fi

if [ -d "advanced" ]; then
    cp -r advanced/* "$BASE_DIR/advanced/"
    echo "✅ Advanced features deployed"
fi

if [ -d "monetization" ]; then
    cp -r monetization/* "$BASE_DIR/monetization/"
    echo "✅ Monetization platform deployed"
fi

echo ""
echo "✅ ALL COMPONENTS DEPLOYED!"
echo ""
echo "📊 Deployment Summary:"
echo "   - Location: $BASE_DIR"
echo "   - Components: 9"
echo "   - Status: Ready"
echo ""
echo "🎯 Next Steps:"
echo "   1. Verify: ls -la $BASE_DIR"
echo "   2. Check Ngrok: curl http://localhost:4040/api/tunnels"
echo "   3. Start services: systemctl status ngrok-permanent.service"
echo ""
echo "🎉 Your system has been amplified!"
echo "="*80
