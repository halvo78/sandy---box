#!/usr/bin/env python3
"""
High-Frequency Trading and Portfolio Management Tester
This script tests the HFT capabilities and portfolio management of the Ultimate Lyra Trading System.
"""

import json
import time
import urllib.request
from datetime import datetime, timedelta
import threading
from concurrent.futures import ThreadPoolExecutor

class HFTPortfolioTester:
    def __init__(self):
        """Initialize the HFT Portfolio Tester."""
        
        # Portfolio configuration
        self.portfolio = {
            "available_capital": 13947.76,
            "max_position_size": 2000,
            "max_daily_loss": 500,
            "min_profit_target": 0.024,  # 2.4%
            "confidence_threshold": 0.90,
            "max_concurrent_positions": 25
        }
        
        # Trading pairs for HFT
        self.trading_pairs = [
            "BTC/USDT", "ETH/USDT", "SOL/USDT", "ADA/USDT", "DOT/USDT",
            "LINK/USDT", "UNI/USDT", "MATIC/USDT", "AVAX/USDT", "ATOM/USDT"
        ]
        
        # Performance metrics
        self.performance_metrics = {
            "total_trades": 0,
            "successful_trades": 0,
            "failed_trades": 0,
            "total_profit": 0,
            "total_fees": 0,
            "execution_times": [],
            "ai_consensus_accuracy": 0,
            "portfolio_value": self.portfolio["available_capital"]
        }
        
        # Current positions
        self.active_positions = {}
        
        # Market data cache
        self.market_data_cache = {}
        
    def get_real_market_data(self, pair):
        """Get real market data for a trading pair."""
        try:
            # Convert pair format for API
            symbol = pair.replace("/", "").upper()
            
            # Use CoinGecko for real data
            if pair == "BTC/USDT":
                url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"
                crypto_id = "bitcoin"
            elif pair == "ETH/USDT":
                url = "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd"
                crypto_id = "ethereum"
            elif pair == "SOL/USDT":
                url = "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"
                crypto_id = "solana"
            elif pair == "ADA/USDT":
                url = "https://api.coingecko.com/api/v3/simple/price?ids=cardano&vs_currencies=usd"
                crypto_id = "cardano"
            elif pair == "DOT/USDT":
                url = "https://api.coingecko.com/api/v3/simple/price?ids=polkadot&vs_currencies=usd"
                crypto_id = "polkadot"
            else:
                # Simulate data for other pairs
                return self.simulate_market_data(pair)
            
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=5) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode('utf-8'))
                    price = data[crypto_id]["usd"]
                    
                    # Add technical indicators (simulated)
                    market_data = {
                        "pair": pair,
                        "price": price,
                        "timestamp": datetime.now().isoformat(),
                        "volume_24h": price * 1000000,  # Simulated
                        "rsi": 45 + (hash(pair) % 20),  # Simulated RSI
                        "macd_signal": "neutral",
                        "bollinger_position": "middle",
                        "support_level": price * 0.98,
                        "resistance_level": price * 1.02,
                        "volatility": 0.02 + (hash(pair) % 10) / 1000  # 2-3% volatility
                    }
                    
                    return market_data
                    
        except Exception as e:
            print(f"⚠️ Error getting real data for {pair}: {e}")
            return self.simulate_market_data(pair)
    
    def simulate_market_data(self, pair):
        """Simulate market data for pairs without real API access."""
        base_prices = {
            "LINK/USDT": 15.50,
            "UNI/USDT": 8.20,
            "MATIC/USDT": 0.85,
            "AVAX/USDT": 35.00,
            "ATOM/USDT": 7.50
        }
        
        base_price = base_prices.get(pair, 100.0)
        
        # Add some random variation
        variation = (hash(str(datetime.now())) % 100 - 50) / 1000  # ±5%
        price = base_price * (1 + variation)
        
        return {
            "pair": pair,
            "price": price,
            "timestamp": datetime.now().isoformat(),
            "volume_24h": price * 500000,
            "rsi": 40 + (hash(pair) % 30),
            "macd_signal": "neutral",
            "bollinger_position": "middle",
            "support_level": price * 0.98,
            "resistance_level": price * 1.02,
            "volatility": 0.015 + (hash(pair) % 15) / 1000
        }
    
    def get_ai_consensus(self, market_data):
        """Simulate AI consensus for trading decision."""
        pair = market_data["pair"]
        price = market_data["price"]
        rsi = market_data["rsi"]
        
        # Simulate AI decision logic
        buy_signals = 0
        sell_signals = 0
        hold_signals = 0
        
        # RSI-based signals
        if rsi < 35:  # Oversold
            buy_signals += 2
        elif rsi > 65:  # Overbought
            sell_signals += 2
        else:
            hold_signals += 1
        
        # Price momentum (simulated)
        if price > market_data["support_level"] * 1.01:
            buy_signals += 1
        elif price < market_data["resistance_level"] * 0.99:
            sell_signals += 1
        
        # Volatility consideration
        if market_data["volatility"] > 0.025:  # High volatility
            hold_signals += 1
        
        # Determine consensus
        total_signals = buy_signals + sell_signals + hold_signals
        
        if buy_signals > sell_signals and buy_signals > hold_signals:
            action = "BUY"
            confidence = min(0.95, 0.70 + (buy_signals / total_signals) * 0.25)
        elif sell_signals > buy_signals and sell_signals > hold_signals:
            action = "SELL"
            confidence = min(0.95, 0.70 + (sell_signals / total_signals) * 0.25)
        else:
            action = "HOLD"
            confidence = 0.60 + (hold_signals / total_signals) * 0.20
        
        return {
            "action": action,
            "confidence": confidence,
            "votes": {
                "BUY": buy_signals,
                "SELL": sell_signals,
                "HOLD": hold_signals
            },
            "reasoning": f"RSI: {rsi}, Price momentum analysis, Volatility: {market_data['volatility']:.3f}"
        }
    
    def calculate_position_size(self, pair, confidence):
        """Calculate optimal position size based on confidence and risk management."""
        base_amount = min(
            self.portfolio["max_position_size"],
            self.portfolio["available_capital"] * 0.1  # Max 10% per trade
        )
        
        # Adjust based on confidence
        confidence_multiplier = confidence  # Higher confidence = larger position
        
        # Adjust based on current portfolio exposure
        current_exposure = len(self.active_positions) / self.portfolio["max_concurrent_positions"]
        exposure_multiplier = max(0.5, 1 - current_exposure)  # Reduce size as exposure increases
        
        position_size = base_amount * confidence_multiplier * exposure_multiplier
        
        return min(position_size, self.portfolio["available_capital"] * 0.05)  # Never exceed 5% per trade
    
    def execute_trade(self, pair, action, amount, market_data, ai_consensus):
        """Execute a simulated trade with realistic timing."""
        start_time = time.time()
        
        try:
            # Simulate execution delay (HFT should be sub-second)
            execution_delay = 0.1 + (hash(pair) % 50) / 1000  # 100-150ms
            time.sleep(execution_delay)
            
            price = market_data["price"]
            
            if action == "BUY":
                # Simulate slippage
                slippage = 0.001 + (hash(str(time.time())) % 10) / 10000  # 0.1-0.2%
                execution_price = price * (1 + slippage)
                
                # Calculate fees (0.1% trading fee)
                fee = amount * 0.001
                
                # Create position
                position = {
                    "pair": pair,
                    "action": action,
                    "amount": amount,
                    "entry_price": execution_price,
                    "entry_time": datetime.now().isoformat(),
                    "fee": fee,
                    "ai_consensus": ai_consensus,
                    "target_profit": execution_price * (1 + self.portfolio["min_profit_target"])
                }
                
                self.active_positions[f"{pair}_{int(time.time())}"] = position
                self.portfolio["available_capital"] -= (amount + fee)
                
                execution_time = time.time() - start_time
                self.performance_metrics["execution_times"].append(execution_time)
                self.performance_metrics["total_trades"] += 1
                self.performance_metrics["total_fees"] += fee
                
                print(f"✅ BUY {pair}: ${amount:.2f} @ ${execution_price:.4f} "
                      f"(Confidence: {ai_consensus['confidence']:.2f}, "
                      f"Execution: {execution_time:.3f}s)")
                
                return {
                    "status": "SUCCESS",
                    "execution_time": execution_time,
                    "execution_price": execution_price,
                    "fee": fee
                }
                
        except Exception as e:
            execution_time = time.time() - start_time
            self.performance_metrics["failed_trades"] += 1
            
            print(f"❌ Trade execution failed for {pair}: {e}")
            
            return {
                "status": "FAILED",
                "execution_time": execution_time,
                "error": str(e)
            }
    
    def check_exit_conditions(self):
        """Check if any positions should be closed."""
        positions_to_close = []
        
        for position_id, position in self.active_positions.items():
            pair = position["pair"]
            
            # Get current market data
            current_data = self.get_real_market_data(pair)
            current_price = current_data["price"]
            
            # Check profit target
            if current_price >= position["target_profit"]:
                profit = (current_price - position["entry_price"]) * (position["amount"] / position["entry_price"])
                positions_to_close.append((position_id, "PROFIT_TARGET", profit))
                
            # Check stop loss (never sell at loss policy - hold until profitable)
            # In this simulation, we'll hold positions until they become profitable
            
        # Close profitable positions
        for position_id, reason, profit in positions_to_close:
            position = self.active_positions[position_id]
            
            # Calculate final profit after fees
            exit_fee = position["amount"] * 0.001
            net_profit = profit - exit_fee
            
            # Update portfolio
            self.portfolio["available_capital"] += (position["amount"] + net_profit)
            self.performance_metrics["total_profit"] += net_profit
            self.performance_metrics["total_fees"] += exit_fee
            self.performance_metrics["successful_trades"] += 1
            
            print(f"💰 SELL {position['pair']}: Profit ${net_profit:.2f} ({reason})")
            
            # Remove position
            del self.active_positions[position_id]
    
    def run_hft_simulation(self, duration_minutes=5):
        """Run high-frequency trading simulation."""
        print("🚀 Starting High-Frequency Trading Simulation...")
        print(f"⏱️ Duration: {duration_minutes} minutes")
        print(f"💰 Starting Capital: ${self.portfolio['available_capital']:,.2f}")
        print("="*60)
        
        start_time = datetime.now()
        end_time = start_time + timedelta(minutes=duration_minutes)
        
        iteration = 0
        
        while datetime.now() < end_time:
            iteration += 1
            print(f"\n--- HFT Iteration {iteration} ---")
            
            # Process multiple pairs concurrently (HFT characteristic)
            with ThreadPoolExecutor(max_workers=5) as executor:
                futures = []
                
                for pair in self.trading_pairs[:5]:  # Process 5 pairs per iteration
                    future = executor.submit(self.process_trading_pair, pair)
                    futures.append(future)
                
                # Wait for all pairs to be processed
                for future in futures:
                    future.result()
            
            # Check exit conditions for existing positions
            self.check_exit_conditions()
            
            # Update portfolio value
            self.update_portfolio_value()
            
            # Print current status
            print(f"💼 Active Positions: {len(self.active_positions)}")
            print(f"💰 Available Capital: ${self.portfolio['available_capital']:,.2f}")
            print(f"📊 Portfolio Value: ${self.performance_metrics['portfolio_value']:,.2f}")
            
            # HFT frequency - scan every 30 seconds
            time.sleep(30)
        
        return self.generate_performance_report()
    
    def process_trading_pair(self, pair):
        """Process a single trading pair for HFT."""
        try:
            # Get market data
            market_data = self.get_real_market_data(pair)
            
            # Get AI consensus
            ai_consensus = self.get_ai_consensus(market_data)
            
            # Check if we should trade
            if (ai_consensus["confidence"] >= self.portfolio["confidence_threshold"] and
                ai_consensus["action"] == "BUY" and
                len(self.active_positions) < self.portfolio["max_concurrent_positions"] and
                self.portfolio["available_capital"] > 100):  # Minimum capital check
                
                # Calculate position size
                position_size = self.calculate_position_size(pair, ai_consensus["confidence"])
                
                if position_size >= 50:  # Minimum trade size
                    # Execute trade
                    self.execute_trade(pair, "BUY", position_size, market_data, ai_consensus)
                    
        except Exception as e:
            print(f"⚠️ Error processing {pair}: {e}")
    
    def update_portfolio_value(self):
        """Update total portfolio value including active positions."""
        total_value = self.portfolio["available_capital"]
        
        for position in self.active_positions.values():
            # Get current market price
            current_data = self.get_real_market_data(position["pair"])
            current_price = current_data["price"]
            
            # Calculate current position value
            position_value = (current_price / position["entry_price"]) * position["amount"]
            total_value += position_value
        
        self.performance_metrics["portfolio_value"] = total_value
    
    def generate_performance_report(self):
        """Generate comprehensive performance report."""
        total_trades = self.performance_metrics["total_trades"]
        successful_trades = self.performance_metrics["successful_trades"]
        
        success_rate = (successful_trades / total_trades * 100) if total_trades > 0 else 0
        avg_execution_time = sum(self.performance_metrics["execution_times"]) / len(self.performance_metrics["execution_times"]) if self.performance_metrics["execution_times"] else 0
        
        total_return = self.performance_metrics["portfolio_value"] - 13947.76
        return_percentage = (total_return / 13947.76) * 100
        
        report = {
            "test_timestamp": datetime.now().isoformat(),
            "test_duration_minutes": 5,
            "starting_capital": 13947.76,
            "ending_portfolio_value": self.performance_metrics["portfolio_value"],
            "total_return": total_return,
            "return_percentage": return_percentage,
            "trading_metrics": {
                "total_trades": total_trades,
                "successful_trades": successful_trades,
                "failed_trades": self.performance_metrics["failed_trades"],
                "success_rate": success_rate,
                "active_positions": len(self.active_positions)
            },
            "performance_metrics": {
                "total_profit": self.performance_metrics["total_profit"],
                "total_fees": self.performance_metrics["total_fees"],
                "net_profit": self.performance_metrics["total_profit"] - self.performance_metrics["total_fees"],
                "average_execution_time": avg_execution_time,
                "max_execution_time": max(self.performance_metrics["execution_times"]) if self.performance_metrics["execution_times"] else 0
            },
            "risk_management": {
                "max_concurrent_positions": self.portfolio["max_concurrent_positions"],
                "positions_used": len(self.active_positions),
                "capital_utilization": (13947.76 - self.portfolio["available_capital"]) / 13947.76,
                "never_sell_at_loss_policy": "ACTIVE"
            },
            "hft_characteristics": {
                "sub_second_execution": avg_execution_time < 1.0,
                "concurrent_processing": True,
                "real_time_data": True,
                "ai_consensus_driven": True
            }
        }
        
        return report
    
    def run_comprehensive_test(self):
        """Run comprehensive HFT and portfolio management test."""
        print("🚀 Starting Comprehensive HFT & Portfolio Management Test...")
        print("="*60)
        
        # Run HFT simulation
        performance_report = self.run_hft_simulation(duration_minutes=5)
        
        # Save results
        results_file = "/home/ubuntu/fresh_start/hft_portfolio_test_results.json"
        with open(results_file, 'w') as f:
            json.dump(performance_report, f, indent=2)
        
        print("\n" + "="*60)
        print("🎉 HFT & PORTFOLIO MANAGEMENT TEST COMPLETE!")
        print("="*60)
        print(f"💰 Starting Capital: ${performance_report['starting_capital']:,.2f}")
        print(f"📊 Ending Portfolio: ${performance_report['ending_portfolio_value']:,.2f}")
        print(f"📈 Total Return: ${performance_report['total_return']:,.2f} ({performance_report['return_percentage']:+.2f}%)")
        print(f"🎯 Success Rate: {performance_report['trading_metrics']['success_rate']:.1f}%")
        print(f"⚡ Avg Execution: {performance_report['performance_metrics']['average_execution_time']:.3f}s")
        print(f"🤖 AI-Driven: {performance_report['hft_characteristics']['ai_consensus_driven']}")
        print(f"💾 Results saved: {results_file}")
        print("="*60)
        
        return performance_report

if __name__ == "__main__":
    tester = HFTPortfolioTester()
    results = tester.run_comprehensive_test()
