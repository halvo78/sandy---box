#!/bin/bash
# Ultimate Lyra Trading System - Ubuntu Installation Script
# Version: 6.0-UNIFIED Final Edition

echo "🚀 Installing Ultimate Lyra Trading System on Ubuntu..."
echo "=================================================="

# Update system
echo "📦 Updating Ubuntu system..."
sudo apt update && sudo apt upgrade -y

# Install Python 3 and essential packages
echo "🐍 Installing Python and dependencies..."
sudo apt install python3 python3-pip python3-venv git curl wget unzip -y

# Create project directory
echo "📁 Creating project directory..."
mkdir -p ~/ultimate_lyra_trading_system
cd ~/ultimate_lyra_trading_system

# Extract system files if zip exists
if [ -f "ULTIMATE_LYRA_COMPLETE_INTEGRATED_SYSTEM.zip" ]; then
    echo "📦 Extracting complete system..."
    unzip -q ULTIMATE_LYRA_COMPLETE_INTEGRATED_SYSTEM.zip
fi

# Set permissions
echo "🔐 Setting file permissions..."
chmod +x *.py
chmod +x *.sh

# Create virtual environment
echo "🌐 Creating Python virtual environment..."
python3 -m venv lyra_env
source lyra_env/bin/activate

# Install Python packages (minimal requirements)
echo "📚 Installing Python packages..."
pip3 install --upgrade pip

echo ""
echo "✅ Ultimate Lyra Trading System installation complete!"
echo "=================================================="
echo "🔑 Next steps:"
echo "1. Configure your OpenRouter API keys in MASTER_CONFIGURATION.json"
echo "2. Configure exchange API credentials (OKX, Binance, etc.)"
echo "3. Test the AI consensus system:"
echo "   python3 ULTIMATE_AI_CONSENSUS_SYSTEM.py"
echo "4. Start trading operations"
echo ""
echo "📚 Documentation:"
echo "- ULTIMATE_UNIFIED_INTEGRATION_REPORT.md"
echo "- COMPLETE_AMALGAMATION_CHECKLIST.md"
echo "- FINAL_SYSTEM_VALIDATION_REPORT.md"
echo ""
echo "🎯 System Features:"
echo "- 8 OpenRouter API keys for AI consensus"
echo "- 17+ premium AI models (GPT-4o, Claude-3.5, etc.)"
echo "- Multi-exchange trading (10+ exchanges)"
echo "- High-frequency trading capabilities"
echo "- Advanced risk management"
echo "- Complete portfolio management"
echo ""
echo "🚀 Ready for live trading operations!"
