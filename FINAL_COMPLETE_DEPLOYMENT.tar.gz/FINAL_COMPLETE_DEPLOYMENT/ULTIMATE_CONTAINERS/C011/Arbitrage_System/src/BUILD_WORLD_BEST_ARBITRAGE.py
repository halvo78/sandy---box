#!/usr/bin/env python3
"""
AI Consensus Builder for World's Best Arbitrage System
Uses OpenRouter to query 6 top AI models for consensus
"""

import requests
import json
import os
from datetime import datetime

API_KEY = os.getenv("OPENROUTER_API_KEY", "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")

TOP_MODELS = [
    "anthropic/claude-3.5-sonnet",
    "openai/gpt-4-turbo",
    "meta-llama/llama-3.1-405b-instruct",
    "qwen/qwen-2.5-72b-instruct",
    "deepseek/deepseek-chat",
    "mistralai/mistral-large"
]

PROMPT = """
Design the WORLD'S BEST cryptocurrency arbitrage system for institutional trading.

Requirements:
1. Cross-exchange arbitrage (8 exchanges: OKX, Binance, Coinbase, Kraken, Gate.io, Bitfinex, Bitstamp, Gemini)
2. Triangular arbitrage (multi-asset cycles)
3. Statistical arbitrage (ML-driven mean reversion)
4. Latency arbitrage (sub-millisecond execution)
5. DeFi arbitrage (DEX + CEX opportunities)
6. Funding rate arbitrage (perpetual futures)
7. Real-time opportunity detection
8. Risk management and position sizing
9. Fee optimization
10. Slippage minimization

Provide a comprehensive architecture with:
- Key algorithms and strategies
- Performance targets (latency, profit margins, success rate)
- Risk management approach
- Technology stack recommendations
- Best practices from institutional firms

Response format: Detailed technical architecture (500-1000 words)
"""

def query_model(model: str) -> dict:
    """Query a single OpenRouter model"""
    try:
        print(f"🤖 Querying {model}...")
        response = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": PROMPT}],
                "max_tokens": 2000
            },
            timeout=60
        )
        
        if response.status_code == 200:
            data = response.json()
            content = data['choices'][0]['message']['content']
            print(f"✅ {model}: {len(content)} characters")
            return {
                "model": model,
                "response": content,
                "timestamp": datetime.utcnow().isoformat(),
                "success": True
            }
        else:
            print(f"❌ {model}: HTTP {response.status_code}")
            return {"model": model, "error": f"HTTP {response.status_code}", "success": False}
            
    except Exception as e:
        print(f"❌ {model}: {str(e)}")
        return {"model": model, "error": str(e), "success": False}

def main():
    print("=" * 80)
    print("🚀 BUILDING WORLD'S BEST ARBITRAGE SYSTEM")
    print("=" * 80)
    print()
    print("Querying 6 top AI models for consensus...")
    print()
    
    results = []
    total_chars = 0
    
    for model in TOP_MODELS:
        result = query_model(model)
        results.append(result)
        if result.get("success"):
            total_chars += len(result.get("response", ""))
        print()
    
    # Save results
    output = {
        "timestamp": datetime.utcnow().isoformat(),
        "models_queried": len(TOP_MODELS),
        "successful_responses": sum(1 for r in results if r.get("success")),
        "total_characters": total_chars,
        "results": results
    }
    
    with open("WORLD_BEST_ARBITRAGE_AI_CONSENSUS.json", "w") as f:
        json.dump(output, f, indent=2)
    
    print("=" * 80)
    print("✅ AI CONSENSUS COMPLETE!")
    print("=" * 80)
    print(f"Models queried: {len(TOP_MODELS)}")
    print(f"Successful responses: {output['successful_responses']}")
    print(f"Total characters: {total_chars:,}")
    print(f"Results saved to: WORLD_BEST_ARBITRAGE_AI_CONSENSUS.json")
    print()

if __name__ == "__main__":
    main()

