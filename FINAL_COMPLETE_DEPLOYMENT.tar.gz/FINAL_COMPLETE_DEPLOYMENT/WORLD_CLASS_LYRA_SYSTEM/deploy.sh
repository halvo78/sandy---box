#!/bin/bash
# Deploy World-Class Lyra System

set -e

echo "🚀 Deploying World-Class Lyra System"
echo "======================================"

# Check requirements
echo "Checking requirements..."
command -v python3 >/dev/null 2>&1 || { echo "Python 3 required"; exit 1; }
command -v node >/dev/null 2>&1 || { echo "Node.js required"; exit 1; }

# Deploy HFT Core
echo ""
echo "📦 Deploying HFT Core..."
cd hft-core
if [ -f "requirements.txt" ]; then
    pip3 install -r requirements.txt
fi
cd ..

# Deploy Dashboard
echo ""
echo "📦 Deploying Dashboard..."
cd dashboard-ui
if [ -f "package.json" ]; then
    pnpm install
    pnpm build
fi
cd ..

# Deploy API Layer
echo ""
echo "📦 Deploying API Layer..."
cd api-integration
if [ -f "requirements.txt" ]; then
    pip3 install -r requirements.txt
fi
cd ..

echo ""
echo "✅ Deployment Complete!"
echo ""
echo "Next steps:"
echo "1. Configure environment variables"
echo "2. Start services with ./start.sh"
echo "3. Access dashboard at http://localhost:3000"
