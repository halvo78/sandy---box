export function TransactionTable() {
  return (
    <div className="card">
      <div className="card-header">
        <h3 className="card-title">TransactionTable</h3>
      </div>
      <div className="card-content">
        <p>Component coming soon...</p>
      </div>
    </div>
  )
}
