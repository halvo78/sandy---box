# compliance_module_main.py

from compliance_test_engine import ComplianceTestEngine
from regulatory_reporting_generator import RegulatoryReportingGenerator
from audit_system_integrator import AuditSystemIntegrator

class ComplianceModule:
    def __init__(self, audit_api_key=""):
        self.test_engine = ComplianceTestEngine()
        self.report_generator = RegulatoryReportingGenerator()
        self.audit_integrator = AuditSystemIntegrator(audit_api_key)

        # Add some example compliance rules
        self.test_engine.add_rule("No trading in sanctioned entities")
        self.test_engine.add_rule("Position limits must not be exceeded")
        self.test_engine.add_rule("All trades must have valid authorization")

        # Add example report templates
        self.report_generator.add_report_template("DailyComplianceSummary", "templates/daily_compliance_summary.html")
        self.report_generator.add_report_template("SuspiciousActivityReport", "templates/sar_template.html")

    def process_trade(self, trade_data):
        print(f"\n--- Processing Trade: {trade_data['trade_id']} ---")
        # 1. Run compliance tests
        compliance_results = self.test_engine.run_tests(trade_data)
        is_trade_compliant = all(res['compliant'] for res in compliance_results)
        print(f"Compliance Results for Trade {trade_data['trade_id']}: {compliance_results}")

        # 2. Log to audit system
        audit_log_entry = {
            "event": "trade_processed",
            "trade_id": trade_data['trade_id'],
            "asset": trade_data['asset'],
            "amount": trade_data['amount'],
            "compliance_status": "compliant" if is_trade_compliant else "non-compliant",
            "compliance_details": compliance_results
        }
        self.audit_integrator.send_audit_log(audit_log_entry)

        # 3. Generate reports if necessary (e.g., for non-compliant trades)
        if not is_trade_compliant:
            print(f"Non-compliant trade detected: {trade_data['trade_id']}. Generating Suspicious Activity Report.")
            sar_data = {"trade_info": trade_data, "compliance_issues": compliance_results}
            sar_report = self.report_generator.generate_report("SuspiciousActivityReport", sar_data)
            print("SAR Report Generated.")
            # In a real system, this report would be securely transmitted

        return is_trade_compliant

    def generate_daily_summary_report(self, daily_compliance_data):
        print("\n--- Generating Daily Compliance Summary Report ---")
        report_content = self.report_generator.generate_report("DailyComplianceSummary", daily_compliance_data)
        print("Daily Compliance Summary Report Generated.")
        return report_content

    def retrieve_audit_history(self, query):
        print(f"\n--- Retrieving Audit History for query: '{query}' ---")
        audit_data = self.audit_integrator.get_audit_data(query)
        print("Audit History Retrieved.")
        return audit_data

# Main execution block for demonstration
if __name__ == "__main__":
    compliance_module = ComplianceModule(audit_api_key="YOUR_EXTERNAL_AUDIT_API_KEY")

    # Simulate some trades
    trade1 = {"trade_id": "T001", "asset": "ETH", "amount": 5000, "type": "buy", "authorized": True}
    trade2 = {"trade_id": "T002", "asset": "XRP", "amount": 25000, "type": "sell", "authorized": False} # Non-compliant
    trade3 = {"trade_id": "T003", "asset": "BTC", "amount": 10000, "type": "buy", "authorized": True}

    compliance_module.process_trade(trade1)
    compliance_module.process_trade(trade2)
    compliance_module.process_trade(trade3)

    # Simulate daily compliance data
    daily_data = {
        "date": "2025-10-14",
        "total_trades": 3,
        "compliant_trades": 2,
        "non_compliant_trades": 1,
        "issues_flagged": ["Unauthorized trade"]
    }
    compliance_module.generate_daily_summary_report(daily_data)

    # Retrieve audit data
    audit_records = compliance_module.retrieve_audit_history("trade_processed")
    print("\nAudit Records:", audit_records)

