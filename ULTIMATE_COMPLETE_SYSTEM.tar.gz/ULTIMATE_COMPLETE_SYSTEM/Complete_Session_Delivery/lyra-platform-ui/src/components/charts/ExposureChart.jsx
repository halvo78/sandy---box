export function ExposureChart() {
  return (
    <div className="card">
      <div className="card-header">
        <h3 className="card-title">ExposureChart</h3>
      </div>
      <div className="card-content">
        <p>Component coming soon...</p>
      </div>
    </div>
  )
}
