export function ComplianceMetrics() {
  return (
    <div className="card">
      <div className="card-header">
        <h3 className="card-title">ComplianceMetrics</h3>
      </div>
      <div className="card-content">
        <p>Component coming soon...</p>
      </div>
    </div>
  )
}
