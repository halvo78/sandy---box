#!/bin/bash
#
# DEPLOY COMPLETE SYSTEM
# Master deployment script for the Ultimate Complete Trading System
#

set -e

echo "🚀 DEPLOYING ULTIMATE COMPLETE SYSTEM"
echo "======================================"
echo ""

# Check if running on Ubuntu
if [ ! -f /etc/lsb-release ]; then
    echo "❌ This script must run on Ubuntu"
    exit 1
fi

# Get user's home directory
USER_HOME=$(eval echo ~$USER)
DEPLOY_DIR="$USER_HOME/ultimate_lyra_systems/ULTIMATE_COMPLETE_SYSTEM"

echo "📍 Deployment directory: $DEPLOY_DIR"
echo ""

# Create deployment directory
mkdir -p "$DEPLOY_DIR"

# Copy all components
echo "📦 Copying system components..."
cp -r * "$DEPLOY_DIR/"

echo ""
echo "✅ DEPLOYMENT COMPLETE!"
echo ""
echo "📊 Next steps:"
echo "  1. cd $DEPLOY_DIR"
echo "  2. Review the README.md files in each directory"
echo "  3. Configure your environment variables"
echo "  4. Run the individual component deployment scripts"
echo ""
