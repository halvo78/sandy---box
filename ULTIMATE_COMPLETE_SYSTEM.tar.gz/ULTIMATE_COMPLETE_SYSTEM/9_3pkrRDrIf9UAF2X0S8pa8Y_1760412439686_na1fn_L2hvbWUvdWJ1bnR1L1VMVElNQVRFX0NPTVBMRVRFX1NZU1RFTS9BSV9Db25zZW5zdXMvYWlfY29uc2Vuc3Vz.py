
import random
import logging
from collections import Counter

# Assuming COMPLETE_ECOSYSTEM.py is in the same parent directory or accessible via PYTHONPATH
# For this example, we'll simulate the import or assume it's directly available.
# In a real scenario, you'd have a proper import path or package structure.

from ..Complete_Ecosystem.COMPLETE_ECOSYSTEM import ai_models, get_ai_model

# The AIModel class is now defined in COMPLETE_ECOSYSTEM.py
# and ai_models list is imported from there.


class AIConsensus:
    def __init__(self, models, logging_level=logging.INFO):
        self.models = models
        self.model_weights = {model.name: 1.0 for model in models} # Initial equal weights
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging_level)
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

    def _update_model_weights(self, model_name, actual_outcome, recommendation, confidence):
        # This is a simplified example. In a real system, this would be more sophisticated.
        # e.g., based on a reinforcement learning algorithm or a more complex performance metric.
        if recommendation == actual_outcome:
            # Increase weight for correct predictions, especially with high confidence
            self.model_weights[model_name] = min(self.model_weights[model_name] * (1 + confidence * 0.1), 2.0)
        else:
            # Decrease weight for incorrect predictions
            self.model_weights[model_name] = max(self.model_weights[model_name] * (1 - confidence * 0.05), 0.5)
        self.logger.debug(f"Updated weight for {model_name}: {self.model_weights[model_name]:.2f}")

    def get_consensus(self, market_data, decision_threshold=0.6, conflict_threshold=0.1):
        """
        Gathers recommendations from all AI models and calculates a weighted consensus.

        Args:
            market_data (dict): Current market data to feed to AI models.
            decision_threshold (float): Minimum aggregated score for a strong consensus.
            conflict_threshold (float): If BUY/SELL scores are within this range, it's a conflict.

        Returns:
            tuple: (consensus_recommendation, consensus_score, detailed_votes)
        """
        individual_votes = []
        for model in self.models:
            recommendation, confidence = model.get_recommendation(market_data)
            weight = self.model_weights.get(model.name, 1.0) * model.historical_accuracy # Incorporate historical accuracy
            individual_votes.append({
                'model': model.name,
                'recommendation': recommendation,
                'confidence': confidence,
                'weight': weight,
                'weighted_score': confidence * weight
            })

        # Aggregate weighted scores for each recommendation type
        aggregated_scores = Counter()
        for vote in individual_votes:
            if vote['recommendation'] == 'BUY':
                aggregated_scores['BUY'] += vote['weighted_score']
            elif vote['recommendation'] == 'SELL':
                aggregated_scores['SELL'] += vote['weighted_score']
            else: # HOLD
                aggregated_scores['HOLD'] += vote['weighted_score']

        total_score = sum(aggregated_scores.values())
        if total_score == 0: # Avoid division by zero if all weights are zero or no votes
            self.logger.warning("No valid votes received, defaulting to HOLD.")
            return 'HOLD', 0.0, individual_votes

        # Normalize aggregated scores
        normalized_scores = {rec: score / total_score for rec, score in aggregated_scores.items()}

        # Determine primary consensus
        if not normalized_scores:
            return 'HOLD', 0.0, individual_votes

        consensus_recommendation = max(normalized_scores, key=normalized_scores.get)
        consensus_score = normalized_scores[consensus_recommendation]

        # Conflict resolution and decision making
        if consensus_score < decision_threshold:
            self.logger.info(f"Consensus score {consensus_score:.2f} below decision threshold {decision_threshold}. Defaulting to HOLD.")
            consensus_recommendation = 'HOLD'

        # Check for close BUY/SELL scores indicating conflict
        buy_score = normalized_scores.get('BUY', 0)
        sell_score = normalized_scores.get('SELL', 0)
        if abs(buy_score - sell_score) < conflict_threshold and (buy_score > 0 or sell_score > 0):
            self.logger.warning(f"Conflict detected: BUY score {buy_score:.2f}, SELL score {sell_score:.2f}. Defaulting to HOLD.")
            consensus_recommendation = 'HOLD'

        self.logger.info(f"Final Consensus: {consensus_recommendation} with score {consensus_score:.2f}")
        return consensus_recommendation, consensus_score, individual_votes

    def provide_feedback(self, model_name, actual_outcome, recommendation, confidence):
        """
        Provides feedback to a specific model to update its weight based on actual outcome.
        """\n        self.logger.info(f"Feedback for {model_name}: Actual {actual_outcome}, Recommended {recommendation}, Confidence {confidence:.2f}")
        self._update_model_weights(model_name, actual_outcome, recommendation, confidence)


if __name__ == "__main__":
    # Example Usage:
    logging.basicConfig(level=logging.INFO)

    # Initialize the consensus mechanism with the simulated AI models
    consensus_system = AIConsensus(ai_models)

    # Simulate market data
    current_market_data = {"asset": "BTC/USDT", "price": 60000, "volatility": "low"}

    # Get consensus
    recommendation, score, details = consensus_system.get_consensus(current_market_data)
    print(f"\nOverall Trading Recommendation: {recommendation} (Score: {score:.2f})")
    print("\nDetailed Votes:")
    for vote in details:
        print(f"  - {vote['model']}: {vote['recommendation']} (Confidence: {vote['confidence']:.2f}, Weight: {vote['weight']:.2f}, Weighted Score: {vote['weighted_score']:.2f})")

    # Simulate feedback for one model (e.g., Model_1 made a good call)
    # In a real system, this feedback would come from actual trade outcomes.
    print("\nSimulating feedback...")
    model_to_feedback = get_ai_model("Model_1")
    if model_to_feedback:
        # Assuming Model_1 recommended BUY with 0.8 confidence and the actual outcome was BUY
        consensus_system.provide_feedback("Model_1", "BUY", "BUY", 0.8)
        print(f"New weight for Model_1: {consensus_system.model_weights['Model_1']:.2f}")

    # Get consensus again to see if weights changed the outcome
    print("\nGetting consensus after feedback...")
    recommendation_after_feedback, score_after_feedback, _ = consensus_system.get_consensus(current_market_data)
    print(f"Overall Trading Recommendation (after feedback): {recommendation_after_feedback} (Score: {score_after_feedback:.2f})")


