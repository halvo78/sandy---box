# AI Consensus - Integration Guide

## 1. Introduction
This guide provides instructions for integrating the AI Consensus component into the Ultimate Complete Trading System. It covers the necessary steps to connect the consensus mechanism with existing AI models, risk management systems, and exchange API integrations.

## 2. Component Overview
The AI Consensus component (`ai_consensus.py`) is responsible for aggregating recommendations from multiple AI models, applying dynamic weighting, and producing a unified trading decision (BUY, SELL, HOLD) with an associated confidence score. It relies on the `COMPLETE_ECOSYSTEM.py` for accessing individual AI models.

## 3. Integration Steps

### 3.1. Prerequisites
*   Ensure the `AI_Consensus` directory and its contents (`ai_consensus.py`, `Docs/`) are placed within the `/home/ubuntu/ULTIMATE_COMPLETE_SYSTEM/` directory.
*   Ensure the `Complete_Ecosystem` directory containing `COMPLETE_ECOSYSTEM.py` is also present in `/home/ubuntu/ULTIMATE_COMPLETE_SYSTEM/`.
*   Python 3.8+ installed with `logging` and `collections` libraries (standard Python libraries).

### 3.2. AI Model Integration (`COMPLETE_ECOSYSTEM.py`)
1.  **Verify `AIModel` Class:** Ensure that `COMPLETE_ECOSYSTEM.py` defines an `AIModel` class with `__init__(self, name, api_key)` and a `get_recommendation(self, market_data)` method that returns a `(recommendation, confidence)` tuple.
2.  **Populate `ai_models` List:** The `ai_models` list in `COMPLETE_ECOSYSTEM.py` should be populated with instances of your 19 AI models, each initialized with its name and relevant API key.

    ```python
    # Example from COMPLETE_ECOSYSTEM.py
    ai_models = [
        AIModel("Model_1", "key_1"),
        AIModel("Model_2", "key_2"),
        # ... up to AIModel("Model_19", "key_19"),
    ]
    ```

### 3.3. Incorporating AI Consensus into the Main Trading Logic
To use the `AIConsensus` component, you will typically instantiate it in your main trading application (e.g., `main.py` or a core trading engine file) and call its `get_consensus` method.

1.  **Import:** Import the `AIConsensus` class and the `ai_models` list:

    ```python
    from AI_Consensus.ai_consensus import AIConsensus
    from Complete_Ecosystem.COMPLETE_ECOSYSTEM import ai_models
    ```

2.  **Instantiation:** Create an instance of `AIConsensus`:

    ```python
    consensus_system = AIConsensus(ai_models, logging_level=logging.INFO)
    ```

3.  **Get Recommendation:** Call `get_consensus` with current market data:

    ```python
    market_data = {"asset": "BTC/USDT", "price": 60000, "volatility": "low"}
    recommendation, score, details = consensus_system.get_consensus(market_data)
    print(f"Trading Recommendation: {recommendation} (Score: {score:.2f})")
    ```

4.  **Provide Feedback (Optional but Recommended):** After a trade is executed and its outcome is known, provide feedback to the consensus system to enable dynamic weight adjustments:

    ```python
    # Assuming 'actual_outcome' is the real result of the trade (e.g., "BUY", "SELL", "HOLD")
    # and 'vote' comes from the 'details' returned by get_consensus
    for vote in details:
        consensus_system.provide_feedback(vote["model"], actual_outcome, vote["recommendation"], vote["confidence"])
    ```

### 3.4. Integration with Risk Management System (`All_5_Systems/risk_management_system.py`)
Before executing any trade based on the consensus recommendation, the decision should be passed to the risk management system for validation.

1.  **Interface:** The risk management system should expose an interface (e.g., a function `check_risk(recommendation, asset, amount)`) that returns `True` if the trade is permissible, `False` otherwise.
2.  **Call Flow:**

    ```python
    # Assuming risk_management_system is imported
    # from All_5_Systems.risk_management_system import check_risk

    recommendation, score, _ = consensus_system.get_consensus(market_data)

    if recommendation != "HOLD" and score >= MIN_CONSENSUS_SCORE_FOR_TRADE:
        if check_risk(recommendation, market_data["asset"], TRADE_AMOUNT):
            # Proceed with trade execution
            print(f"Risk check passed. Executing {recommendation} for {market_data["asset"]}")
        else:
            print(f"Risk check failed for {recommendation} on {market_data["asset"]}. Aborting trade.")
    else:
        print("No strong consensus or recommendation is HOLD. No trade executed.")
    ```

### 3.5. Integration with Exchange API Wrappers (`API_Integrations/`)
Once a trading decision is validated by the risk management system, it can be executed via the appropriate exchange API wrapper.

1.  **Interface:** Exchange API wrappers should provide methods like `execute_buy(asset, amount)` and `execute_sell(asset, amount)`.
2.  **Call Flow:**

    ```python
    # Assuming exchange_api_wrapper is imported
    # from API_Integrations.exchange_api_wrapper import execute_buy, execute_sell

    if recommendation == "BUY":
        trade_result = execute_buy(market_data["asset"], TRADE_AMOUNT)
        print(f"BUY order executed: {trade_result}")
    elif recommendation == "SELL":
        trade_result = execute_sell(market_data["asset"], TRADE_AMOUNT)
        print(f"SELL order executed: {trade_result}")
    ```

## 4. Configuration
Refer to `Configuration_Templates.md` for details on configuring the AI Consensus component and its dependencies.

## 5. Logging and Monitoring
Ensure that logging is properly configured as described in `Error_Handling.md`. Integrate the AI Consensus logs into your centralized monitoring system for real-time insights and alerts.

## 6. Testing
Before deploying to production, ensure all tests outlined in `Testing_Checklist.md` are successfully completed.

This guide ensures a smooth and secure integration of the AI Consensus component, enhancing the overall intelligence and reliability of the Ultimate Complete Trading System.
