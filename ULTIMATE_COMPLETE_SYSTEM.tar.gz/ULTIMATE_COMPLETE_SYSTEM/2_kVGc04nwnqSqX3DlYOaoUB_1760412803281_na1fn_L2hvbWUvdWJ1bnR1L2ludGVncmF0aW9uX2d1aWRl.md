# Risk Management System: Integration Guide

## 1. Overview

The `RiskManagementSystem` is a critical component of the Ultimate Complete Trading System, designed to enforce financial controls, manage portfolio risk, and ensure the system operates within predefined safety limits. It leverages an ensemble of AI models to provide dynamic, intelligent risk assessments.

This guide outlines the steps required to integrate the `RiskManagementSystem` into the main trading application.

## 2. Prerequisites

Before integration, ensure the following components are available and accessible:

- **Trading System API:** A well-defined interface (`TradingSystemAPI`) that allows the risk management system to query portfolio information, execute emergency shutdowns, and trigger rebalancing.
- **Data Feed API:** An interface (`DataFeedAPI`) that provides real-time and historical market data for assets.
- **AI Ensemble:** An `EnsembleAI` class that encapsulates the logic for the 19 active AI models, providing methods for risk prediction, correlation analysis, and dynamic parameter enhancement.

## 3. Configuration

The `RiskManagementSystem` is configured through environment variables. Create a `.env` file in the root of your project with the following variables:

```env
# --- Core Financial Controls ---
LIVE_MODE=false
MAX_DAILY_LOSS=500.0
MAX_DRAWDOWN=0.15
CAPITAL_RESERVES_PERCENT=0.28
EMERGENCY_RESERVE_PERCENT=0.10

# --- AI & Trade Parameters ---
# These are base values; the AI ensemble can override them dynamically
MAX_POSITION_SIZE_USD=2000.0
MIN_PROFIT_TARGET_PERCENT=0.024
CORRELATION_THRESHOLD=0.70
AI_CONFIDENCE_THRESHOLD=0.90

# --- System & Logging ---
LOG_LEVEL=INFO
```

**Note:** For production, `LIVE_MODE` must be set to `true` to enable real-money trading and critical safety features like emergency shutdowns.

## 4. Integration Steps

### Step 1: Initialization

Instantiate the `RiskManagementSystem` at the start of your main application logic. It requires instances of the `TradingSystemAPI`, `DataFeedAPI`, and `EnsembleAI`.

```python
from risk_management_system import RiskManagementSystem, TradingSystemAPI, DataFeedAPI, EnsembleAI

# Initialize your system's core components (implement these according to your architecture)
trading_api = TradingSystemAPI()
data_api = DataFeedAPI()
ai_ensemble = EnsembleAI()

# Initialize the Risk Management System
rms = RiskManagementSystem(
    trading_api=trading_api,
    data_api=data_api,
    ai_ensemble=ai_ensemble
)
```

### Step 2: Pre-Trade Checks

Before executing any trade (BUY or SELL), you must call the `run_risk_checks()` method. This is the primary entry point for all risk assessments.

- Create a `trade_proposal` dictionary containing all relevant information about the potential trade.
- The method returns `True` if the trade is approved and `False` if it is rejected.

```python
# Example for a BUY trade proposal
trade_proposal = {
    "symbol": "BTC-USD",
    "type": "BUY",
    "amount": 1500.0, # The amount in USD for the trade
    "current_price": 41000.0,
    "fees": 0.001 # Estimated fees
}

# Run pre-trade risk checks
is_trade_approved = rms.run_risk_checks(trade_proposal=trade_proposal)

if is_trade_approved:
    print("Trade approved by Risk Management. Executing trade...")
    # trading_system.execute_trade(trade_proposal)
else:
    print("Trade rejected by Risk Management. Aborting.")
```

### Step 3: Post-Trade Updates

After a trade is executed and the profit or loss (PnL) is realized, you must inform the `RiskManagementSystem` to update its internal state, particularly the `daily_loss`.

Call `run_risk_checks()` again, this time passing the `trade_pnl`.

```python
# Assume a trade was closed with a realized loss of $50
realized_pnl = -50.0

# Update the RMS with the realized PnL
# This will check if the max daily loss has been breached
if not rms.run_risk_checks(trade_pnl=realized_pnl):
    print("A critical risk threshold was breached post-trade. System may have shut down.")
```

### Step 4: Continuous Monitoring (Optional but Recommended)

For robust protection, it is recommended to run periodic risk checks even when no trades are being executed. This can be done in a background thread or a scheduled task.

This ensures that portfolio-level risks like drawdown and capital reserve levels are monitored continuously.

```python
import time

def continuous_monitoring(rms):
    while True:
        print("Running periodic portfolio risk checks...")
        rms.run_risk_checks() # Call without trade proposal for portfolio-level checks
        time.sleep(300) # Run every 5 minutes

# Start monitoring in a separate thread
# import threading
# monitor_thread = threading.Thread(target=continuous_monitoring, args=(rms,))
# monitor_thread.start()
```

## 5. Security and Error Handling

- **Emergency Shutdown:** The `RiskManagementSystem` will automatically call the `trading_api.emergency_shutdown()` method if critical thresholds (`MAX_DAILY_LOSS`, `MAX_DRAWDOWN`, `EMERGENCY_RESERVE_PERCENT`) are breached. Ensure your `TradingSystemAPI` implementation correctly handles this call by halting all trading activity and liquidating positions if necessary.
- **Logging:** The system provides detailed logs. Monitor these logs closely to understand the system's behavior and identify potential issues.
- **Fail-Safe:** In case of errors within the risk assessment process (e.g., failure to fetch data), the system is designed to fail safely, typically by rejecting the trade or maintaining the last known safe state.

By following this guide, you can effectively integrate the `RiskManagementSystem` to create a secure, reliable, and production-grade trading system.

