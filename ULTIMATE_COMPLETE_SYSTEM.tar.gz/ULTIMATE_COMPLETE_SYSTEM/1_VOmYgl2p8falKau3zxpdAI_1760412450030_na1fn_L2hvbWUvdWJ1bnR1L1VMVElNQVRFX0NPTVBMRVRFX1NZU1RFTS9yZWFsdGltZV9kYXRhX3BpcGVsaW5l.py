
import asyncio
import json
import time
import logging
import os
from datetime import datetime
from typing import Dict, Any, Optional

from API_Integrations.api_wrappers import APIWrapper
from API_Integrations.exchange_integrations import ExchangeIntegration
from AI_Integration.openrouter_integration import OpenRouterAI

# Configure logging
logging.basicConfig(level=logging.INFO, format=
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Custom Exceptions
class DataPipelineError(Exception):
    """Base exception for data pipeline errors."""
    pass

class ExchangeAPIError(DataPipelineError):
    """Raised when an exchange API returns an error."""
    pass

class RateLimitExceeded(ExchangeAPIError):
    """Raised when an exchange API rate limit is exceeded."""
    pass

class DataNormalizationError(DataPipelineError):
    """Raised when data normalization fails."""
    pass

class AIServiceError(DataPipelineError):
    """Raised when the AI service encounters an error."""
    pass


# Placeholder for a message queue client (e.g., Kafka, RabbitMQ)
class MessageQueueClient:
    def __init__(self, broker_address: str):
        self.broker_address = broker_address
        logger.info(f"Initializing MessageQueueClient with broker: {broker_address}")

    async def publish(self, topic: str, message: str, retries: int = 3, delay: int = 1):
        for i in range(retries):
            try:
                logger.debug(f"[MQ] Publishing to {topic}: {message}")
                await asyncio.sleep(0.01) # Simulate network latency
                return True
            except Exception as e:
                logger.error(f"Attempt {i+1}/{retries}: Failed to publish message to topic {topic}: {e}")
                await asyncio.sleep(delay * (2**i)) # Exponential backoff
        logger.critical(f"Failed to publish message to topic {topic} after {retries} attempts. Message sent to DLQ.")
        # In a real system, send to a Dead Letter Queue (DLQ)
        return False

    async def consume(self, topic: str):
        logger.info(f"[MQ] Consuming from {topic}...")
        while True:
            try:
                await asyncio.sleep(1) # Simulate polling interval
                yield {"timestamp": datetime.now().isoformat(), "data": "simulated_raw_data"}
            except Exception as e:
                logger.error(f"Failed to consume message from topic {topic}: {e}")
                await asyncio.sleep(5) # Wait before retrying consumption


class ExchangeDataFetcher:
    def __init__(self, exchange_name: str, api_key: str, secret_key: str, mq_client: MessageQueueClient):
        if not api_key or not secret_key:
            raise ValueError(f"API key or secret key missing for {exchange_name}")

        self.exchange_name = exchange_name
        self.exchange_integration = ExchangeIntegration(api_key, secret_key)
        self.api_wrapper = APIWrapper(f"https://api.{exchange_name.lower()}.com", api_key, secret_key)
        self.mq_client = mq_client
        self.is_running = False
        logger.info(f"Data fetcher initialized for {exchange_name}")

    async def _handle_api_error(self, e: Exception, source: str):
        if "rate limit" in str(e).lower():
            logger.warning(f"Rate limit exceeded for {self.exchange_name} {source}. Retrying after delay.")
            raise RateLimitExceeded(f"Rate limit for {self.exchange_name} {source}") from e
        else:
            logger.error(f"Exchange API error from {self.exchange_name} {source}: {e}")
            raise ExchangeAPIError(f"API error from {self.exchange_name} {source}") from e

    async def connect_websocket(self):
        logger.info(f"Connecting to {self.exchange_name} WebSocket...")
        retry_delay = 1
        while self.is_running:
            try:
                data = {
                    "exchange": self.exchange_name,
                    "symbol": "BTC/USDT",
                    "price": 60000 + (time.time() % 100),
                    "volume": 100 + (time.time() % 10),
                    "timestamp": datetime.now().isoformat()
                }
                await self.mq_client.publish(f"raw_market_data_{self.exchange_name.lower()}", json.dumps(data))
                retry_delay = 1 # Reset delay on success
                await asyncio.sleep(0.5) # Simulate real-time data push
            except RateLimitExceeded:
                await asyncio.sleep(retry_delay * 5) # Longer delay for rate limits
                retry_delay = min(retry_delay * 2, 60) # Max 60 seconds
            except (asyncio.CancelledError, ConnectionError) as e:
                logger.warning(f"WebSocket connection for {self.exchange_name} interrupted: {e}. Reconnecting...")
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 30) # Max 30 seconds
            except Exception as e:
                await self._handle_api_error(e, "WebSocket")
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 30)

    async def fetch_rest_data(self):
        logger.info(f"Fetching {self.exchange_name} REST data...")
        retry_delay = 1
        while self.is_running:
            try:
                # In a real scenario, use self.api_wrapper.get_data()
                data = {
                    "exchange": self.exchange_name,
                    "type": "account_balance",
                    "balance": 100000.0,
                    "currency": "USD",
                    "timestamp": datetime.now().isoformat()
                }
                await self.mq_client.publish(f"raw_account_data_{self.exchange_name.lower()}", json.dumps(data))
                retry_delay = 1 # Reset delay on success
            except RateLimitExceeded:
                await asyncio.sleep(retry_delay * 5)
                retry_delay = min(retry_delay * 2, 60)
            except Exception as e:
                await self._handle_api_error(e, "REST API")
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 30)
            await asyncio.sleep(5) # Fetch every 5 seconds

    async def start(self):
        self.is_running = True
        logger.info(f"Starting data fetcher for {self.exchange_name}")
        await asyncio.gather(
            self.connect_websocket(),
            self.fetch_rest_data()
        )

    def stop(self):
        self.is_running = False
        logger.info(f"Stopping data fetcher for {self.exchange_name}")


class MarketDataProcessor:
    def __init__(self, mq_client: MessageQueueClient, ai_integration: OpenRouterAI):
        self.mq_client = mq_client
        self.ai_integration = ai_integration
        self.is_running = False
        self.unified_schema = {
            "timestamp": None,
            "exchange": None,
            "symbol": None,
            "price": None,
            "volume": None,
            "type": None, # e.g., 'trade', 'orderbook', 'ticker', 'balance'
            "ai_sentiment": None # Enriched by AI
        }
        logger.info("MarketDataProcessor initialized.")

    def _normalize_data(self, raw_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            if not isinstance(raw_data, dict) or "data" not in raw_data:
                logger.warning(f"Invalid raw data format: {raw_data}")
                raise DataNormalizationError("Invalid raw data format")

            normalized_data = self.unified_schema.copy()
            data_dict = json.loads(raw_data["data"])

            normalized_data["timestamp"] = data_dict.get("timestamp")
            normalized_data["exchange"] = data_dict.get("exchange")
            normalized_data["symbol"] = data_dict.get("symbol")
            normalized_data["price"] = float(data_dict["price"]) if "price" in data_dict else None
            normalized_data["volume"] = float(data_dict["volume"]) if "volume" in data_dict else None
            normalized_data["type"] = data_dict.get("type", "market_data")

            if any(val is None for val in [normalized_data["timestamp"], normalized_data["exchange"], normalized_data["symbol"]]):
                logger.warning(f"Missing critical data points after normalization: {normalized_data}")
                raise DataNormalizationError("Missing critical data points")

            return normalized_data
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            logger.error(f"Data normalization failed for raw data {raw_data}: {e}")
            raise DataNormalizationError(f"Normalization error: {e}") from e

    async def _enrich_with_ai(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            if data is None: return None
            prompt = f"Analyze market sentiment for {data.get("symbol")} at price {data.get("price")}"
            # In a real scenario, call self.ai_integration.generate_response(prompt)
            # For now, simulate a response
            ai_response = {"sentiment": "neutral", "confidence": 0.75}
            data["ai_sentiment"] = ai_response["sentiment"]
            return data
        except Exception as e:
            logger.error(f"AI enrichment failed for data {data}: {e}")
            raise AIServiceError(f"AI enrichment error: {e}") from e

    async def process_data(self, topic: str):
        logger.info(f"Starting data processor for topic: {topic}")
        async for raw_message in self.mq_client.consume(topic):
            if not self.is_running: break
            try:
                logger.debug(f"Processing raw message from {topic}: {raw_message}")
                normalized_data = self._normalize_data(raw_message)
                if normalized_data:
                    enriched_data = await self._enrich_with_ai(normalized_data)
                    if enriched_data:
                        await self.mq_client.publish("processed_market_data", json.dumps(enriched_data))
                    else:
                        logger.warning(f"AI enrichment returned no data for {normalized_data}")
                else:
                    logger.warning(f"Normalization returned no data for raw message {raw_message}")
            except DataPipelineError as e:
                logger.error(f"Handled data pipeline error during processing: {e}. Message: {raw_message}")
                # Send to DLQ or specific error topic
            except Exception as e:
                logger.critical(f"Unhandled critical error during data processing for message {raw_message}: {e}")
                # Implement circuit breaker or system shutdown if critical

    async def start(self, topics: list[str]):
        self.is_running = True
        logger.info("Starting MarketDataProcessor")
        processing_tasks = [self.process_data(topic) for topic in topics]
        await asyncio.gather(*processing_tasks)

    def stop(self):
        self.is_running = False
        logger.info("Stopping MarketDataProcessor")


async def main():
    # Configuration (ideally loaded from a config file or environment variables)
    # Security Best Practice: Load API keys from environment variables
    EXCHANGES = {
        "OKX": {
            "api_key": os.getenv("OKX_API_KEY"),
            "secret_key": os.getenv("OKX_SECRET_KEY")
        },
        "Binance": {
            "api_key": os.getenv("BINANCE_API_KEY"),
            "secret_key": os.getenv("BINANCE_SECRET_KEY")
        }
    }
    MQ_BROKER = os.getenv("MESSAGE_QUEUE_BROKER", "localhost:9092") # Placeholder
    OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

    # Validate API keys are set. In a production environment, these should be mandatory.
    for exchange, creds in EXCHANGES.items():
        if not creds["api_key"] or not creds["secret_key"]:
            logger.critical(f"CRITICAL: API keys for {exchange} are not set. Please set environment variables.")
            # In a real system, this might trigger an immediate shutdown or alert.

    if not OPENROUTER_API_KEY:
        logger.critical("CRITICAL: OpenRouter API key is not set. Please set OPENROUTER_API_KEY environment variable.")

    mq_client = MessageQueueClient(MQ_BROKER)
    ai_integration = OpenRouterAI(OPENROUTER_API_KEY or "DUMMY_OPENROUTER_KEY") # Provide dummy if not set for dev/test

    # Initialize and start data fetchers for each exchange
    fetchers = []
    for name, creds in EXCHANGES.items():
        try:
            if creds["api_key"] and creds["secret_key"]:
                fetcher = ExchangeDataFetcher(name, creds["api_key"], creds["secret_key"], mq_client)
                fetchers.append(fetcher)
                asyncio.create_task(fetcher.start())
            else:
                logger.error(f"Skipping {name} data fetcher due to missing API credentials.")
        except ValueError as e:
            logger.error(f"Skipping {name} data fetcher due to configuration error: {e}")

    # Initialize and start market data processor
    processor_topics = [f"raw_market_data_{name.lower()}" for name in EXCHANGES.keys() if EXCHANGES[name]["api_key"]] + \
                       [f"raw_account_data_{name.lower()}" for name in EXCHANGES.keys() if EXCHANGES[name]["api_key"]]
    processor = MarketDataProcessor(mq_client, ai_integration)
    asyncio.create_task(processor.start(processor_topics))

    # Keep the main loop running
    while True:
        await asyncio.sleep(3600) # Run for a long time

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Real-time Data Pipeline stopped by user.")
    except Exception as e:
        logger.critical(f"Real-time Data Pipeline terminated due to unhandled exception: {e}")


