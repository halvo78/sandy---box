# Disaster Recovery System Deployment Instructions

This document outlines the steps required to deploy and configure the Disaster Recovery System, ensuring the resilience and continuity of the Ultimate Complete Trading System.

## 1. Prerequisites

Before deployment, ensure the following are installed and configured on your Ubuntu system:

*   **Python 3.x**: The system is developed in Python.
*   **pip**: Python package installer.
*   **ngrok**: For secure introspectable tunnels to localhost. Install it using:
    ```bash
    if ! command -v ngrok &> /dev/null; then
        echo "ngrok not found, installing..."
        curl -s https://ngrok-agent.s3.amazonaws.com/ngrok.asc | sudo tee /etc/apt/trusted.gpg.d/ngrok.asc >/dev/null
        echo "deb https://ngrok-agent.s3.amazonaws.com buster main" | sudo tee /etc/apt/sources.list.d/ngrok.list
        sudo apt update
        sudo apt install ngrok -y
    else
        echo "ngrok is already installed."
    fi
    ```
*   **ngrok Authtoken**: Obtain an authtoken from your ngrok dashboard (https://dashboard.ngrok.com/get-started/your-authtoken) and set it as an environment variable:
    ```bash
    export NGROK_AUTHTOKEN="YOUR_NGROK_AUTHTOKEN"
    ```
    Alternatively, you can configure it directly using `ngrok config add-authtoken YOUR_NGROK_AUTHTOKEN`.

## 2. System Setup

1.  **Clone the Repository (if applicable)**:
    If the system is in a Git repository, clone it to your deployment environment:
    ```bash
    git clone <repository_url>
    cd ULTIMATE_COMPLETE_SYSTEM
    ```
    For this task, assume the files are already in `/home/ubuntu/ULTIMATE_COMPLETE_SYSTEM/`.

2.  **Install Python Dependencies**:
    Navigate to the project root and install required Python packages. (Currently, only standard libraries are used, but this is a placeholder for future dependencies).
    ```bash
    pip install -r requirements.txt # If a requirements.txt exists
    ```

## 3. Configuration

### Environment Variables

Ensure the following environment variables are set:

*   `NGROK_AUTHTOKEN`: Your ngrok authentication token. This is crucial for `start_ngrok_tunnel` functionality.

### Backup Locations

The `DisasterRecoverySystem` requires at least one backup location. This can be a local directory or a mounted network share. It is recommended to use a dedicated, secure location.

## 4. Running the Disaster Recovery System

### Example Usage

To use the `DisasterRecoverySystem`, you can instantiate it and call its methods. Below is an example of how to initiate a backup and recovery, and manage an ngrok tunnel.

```python
import os
from disaster_recovery_system import DisasterRecoverySystem

# Ensure NGROK_AUTHTOKEN is set in your environment or passed securely
# os.environ["NGROK_AUTHTOKEN"] = "YOUR_NGROK_AUTHTOKEN"

dr_system = DisasterRecoverySystem()

# Add a backup location
backup_dir = "/home/ubuntu/ULTIMATE_COMPLETE_SYSTEM/backups"
if not os.path.exists(backup_dir):
    os.makedirs(backup_dir)
dr_system.add_backup_location(backup_dir)

# Create some dummy data for backup (if not already present)
data_dir = "/home/ubuntu/ULTIMATE_COMPLETE_SYSTEM/data"
if not os.path.exists(data_dir):
    os.makedirs(data_dir)
    with open(os.path.join(data_dir, "important_config.txt"), "w") as f:
        f.write("API_KEY=12345\nSECRET=abcde")
    with open(os.path.join(data_dir, "logs.txt"), "w") as f:
        f.write("System started at ...")

print("\n--- Initiating Backup ---")
dr_system.initiate_backup()

print("\n--- Simulating Data Loss (deleting original data) ---")
if os.path.exists(data_dir):
    import shutil
    shutil.rmtree(data_dir)
    print(f"Deleted {data_dir}")

print("\n--- Initiating Recovery ---")
dr_system.initiate_recovery()

print("\n--- Verifying Recovered Data ---")
if os.path.exists(os.path.join(data_dir, "important_config.txt")):
    with open(os.path.join(data_dir, "important_config.txt"), "r") as f:
        print(f"Recovered config: {f.read().strip()}")
else:
    print("Important config not recovered.")

# Ngrok Integration Example
print("\n--- Starting Ngrok Tunnel ---")
# Assuming your application runs on port 8000
if dr_system.start_ngrok_tunnel(8000):
    print(f"Ngrok tunnel is active at: {getattr(dr_system, 'ngrok_tunnel_url', 'N/A')}")
    # Keep the tunnel open for a short period for demonstration
    # In a real application, this would be managed by a service or event loop
    import time
    time.sleep(10) 
    dr_system.stop_ngrok_tunnel()
else:
    print("Ngrok tunnel could not be started.")

print("\n--- Disaster Recovery Operations Complete ---")
```

## 5. Production-Grade Considerations

*   **Automated Backups**: Schedule `initiate_backup` to run at regular intervals using cron jobs or a dedicated scheduler service.
*   **Offsite Storage**: For true disaster recovery, backup locations should include offsite storage (e.g., S3, Google Cloud Storage) in addition to local backups.
*   **Monitoring and Alerting**: Integrate backup and recovery operations with a monitoring system to alert administrators of failures or successful completions.
*   **Access Control**: Ensure strict access controls are in place for backup directories and recovery procedures.
*   **Ngrok Management**: For persistent Ngrok tunnels in production, consider using `pyngrok` library or Ngrok's official API for more robust management and public URL retrieval, rather than parsing `stdout`.

## 6. Testing Checklist

Refer to `test_disaster_recovery_system.py` for comprehensive unit tests. Key areas to test include:

*   **Backup Creation**: Verify that backup archives are created successfully and contain the expected data.
*   **Data Recovery**: Ensure that data can be fully and accurately restored from backups after simulated data loss.
*   **Ngrok Tunneling**: Test the `start_ngrok_tunnel` and `stop_ngrok_tunnel` functions, verifying that tunnels are established and terminated correctly, and public URLs are retrieved.
*   **Error Handling**: Validate that the system gracefully handles scenarios like missing backup locations, corrupted backups, or ngrok startup failures.
*   **Performance**: Assess the time taken for backup and recovery operations, especially with large datasets.

## 7. Security Best Practices

*   **Encryption**: Encrypt backup archives at rest and in transit.
*   **Access Control**: Implement least privilege access for directories containing sensitive data and backups.
*   **Environment Variables**: Never hardcode sensitive information like `NGROK_AUTHTOKEN` directly in code. Use environment variables or a secure configuration management system.
*   **Audit Logs**: Maintain detailed logs of all backup, recovery, and ngrok operations for auditing and compliance.

This guide provides a foundation for deploying and managing the Disaster Recovery System. Adapt and extend it based on the specific requirements and infrastructure of the Ultimate Complete Trading System.
