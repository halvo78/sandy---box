import os
import subprocess
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class DisasterRecoverySystem:
    def __init__(self):
        self.ngrok_authtoken = os.getenv("NGROK_AUTHTOKEN")
        if not self.ngrok_authtoken:
            logging.warning("NGROK_AUTHTOKEN environment variable not set. Ngrok functionality may be limited.")
        self.backup_locations = []
        self.recovery_procedures = []

    def add_backup_location(self, location):
        self.backup_locations.append(location)
        logging.info(f"Added backup location: {location}")

    def initiate_backup(self):
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        backup_filename = f"backup_{timestamp}.tar.gz"
        backup_path = os.path.join(self.backup_locations[0], backup_filename) if self.backup_locations else backup_filename

        try:
            # Example: Backing up a hypothetical 'data' directory
            # In a real scenario, this would involve specific data sources (DB, configs, logs)
            source_data_path = "/home/ubuntu/ULTIMATE_COMPLETE_SYSTEM/data"
            if not os.path.exists(source_data_path):
                os.makedirs(source_data_path)
                with open(os.path.join(source_data_path, "dummy_data.txt"), "w") as f:
                    f.write("This is dummy data for backup.")

            logging.info(f"Initiating backup of {source_data_path} to {backup_path}...")
            subprocess.run(["tar", "-czf", backup_path, source_data_path], check=True)
            logging.info(f"Backup successful: {backup_path}")
            return True
        except subprocess.CalledProcessError as e:
            logging.error(f"Backup failed: {e}")
            return False
        except Exception as e:
            logging.error(f"An unexpected error occurred during backup: {e}")
            return False

    def initiate_recovery(self):
        if not self.backup_locations:
            logging.warning("No backup locations configured. Recovery aborted.")
            return False

        backup_dir = self.backup_locations[0]
        try:
            # Find the latest backup file
            backup_files = [f for f in os.listdir(backup_dir) if f.startswith("backup_") and f.endswith(".tar.gz")]
            if not backup_files:
                logging.warning(f"No backup files found in {backup_dir}. Recovery aborted.")
                return False

            latest_backup = sorted(backup_files, reverse=True)[0]
            backup_path = os.path.join(backup_dir, latest_backup)

            # Define target directory for recovery (e.g., overwrite the original data directory)
            target_data_path = "/home/ubuntu/ULTIMATE_COMPLETE_SYSTEM/data"
            if os.path.exists(target_data_path):
                logging.info(f"Removing existing data at {target_data_path} before recovery...")
                subprocess.run(["rm", "-rf", target_data_path], check=True)

            logging.info(f"Initiating recovery from {backup_path} to {target_data_path}...")
            subprocess.run(["tar", "-xzf", backup_path, "-C", "/home/ubuntu/ULTIMATE_COMPLETE_SYSTEM/"], check=True)
            logging.info(f"Recovery successful from {backup_path}")
            return True
        except subprocess.CalledProcessError as e:
            logging.error(f"Recovery failed: {e}")
            return False
        except Exception as e:
            logging.error(f"An unexpected error occurred during recovery: {e}")
            return False

    def start_ngrok_tunnel(self, port):
        authtoken = self.ngrok_authtoken
        if not authtoken:
            logging.error("Ngrok authtoken is not available. Cannot start tunnel.")
            return False
        logging.info(f"Starting Ngrok tunnel for port {port}...")
        try:
            if authtoken:
                # Ensure ngrok is configured with the authtoken
                subprocess.run(["ngrok", "config", "add-authtoken", authtoken], check=True)
            
            # Start ngrok in a subprocess. We need to capture its output to get the public URL.
            # For a production system, consider using pyngrok or ngrok's API for better control.
            # This example assumes ngrok is in the PATH.
            command = ["ngrok", "http", str(port), "--log=stdout"]
            self.ngrok_process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1, universal_newlines=True)
            
            # Read ngrok output to find the tunnel URL
            tunnel_url = None
            for line in iter(self.ngrok_process.stdout.readline, ""):
                logging.debug(f"[ngrok] {line.strip()}") # Use debug for verbose ngrok output
                if "url=" in line:
                    # This is a simplified parsing. A more robust solution would use regex.
                    parts = line.split("url=")
                    if len(parts) > 1:
                        tunnel_url = parts[1].split(" ")[0].strip()
                        break
            
            if tunnel_url:
                logging.info(f"Ngrok tunnel established: {tunnel_url}")
                self.ngrok_tunnel_url = tunnel_url
                return True
            else:
                logging.error("Failed to get Ngrok tunnel URL from output.")
                self.stop_ngrok_tunnel() # Clean up if URL not found
                return False

        except FileNotFoundError:
            logging.error("Error: ngrok executable not found. Please ensure ngrok is installed and in your PATH.")
            return False
        except subprocess.CalledProcessError as e:
            logging.error(f"Ngrok configuration or startup failed: {e}")
            return False
        except Exception as e:
            logging.error(f"An unexpected error occurred during Ngrok tunnel startup: {e}")
            return False

    def stop_ngrok_tunnel(self):
        logging.info("Stopping Ngrok tunnel...")
        if hasattr(self, 'ngrok_process') and self.ngrok_process.poll() is None:
            self.ngrok_process.terminate()
            self.ngrok_process.wait()
            logging.info("Ngrok tunnel stopped.")
            if hasattr(self, 'ngrok_tunnel_url'):
                del self.ngrok_tunnel_url
            return True
        else:
            logging.info("No active Ngrok tunnel to stop.")
            return False