#!/bin/bash
# Test script for Security_Framework

set -e

echo "🧪 Testing Security_Framework..."
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Test counters
PASSED=0
FAILED=0

# Function to run test
run_test() {
    TEST_NAME=$1
    TEST_FILE=$2
    
    echo "Running $TEST_NAME..."
    if python3 "$TEST_FILE"; then
        echo -e "${GREEN}✅ $TEST_NAME PASSED${NC}"
        ((PASSED++))
    else
        echo -e "${RED}❌ $TEST_NAME FAILED${NC}"
        ((FAILED++))
    fi
    echo ""
}

# Run all tests
cd "$(dirname "$0")"

if [ -d "tests" ]; then
    run_test "Unit Tests" "tests/test_unit.py"
    run_test "Integration Tests" "tests/test_integration.py"
    run_test "Performance Tests" "tests/test_performance.py"
else
    echo "⚠️  No tests directory found"
fi

# Summary
echo "="
echo "Test Summary:"
echo "  Passed: $PASSED"
echo "  Failed: $FAILED"
echo "="

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}✅ All tests passed!${NC}"
    exit 0
else
    echo -e "${RED}❌ Some tests failed${NC}"
    exit 1
fi
